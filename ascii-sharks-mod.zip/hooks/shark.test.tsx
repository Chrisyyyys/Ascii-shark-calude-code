import { expect, test } from 'claude-code/testing'

const PANE = {
  plugin: 'ascii-sharks',
  component: 'Pane',
  requestId: 'ascii-sharks',
  props: {
    title: 'Sharks',
    isFocused: false,
    bodyColumns: 70,
    placement: 'dock',
    scroll: { offset: 0, bodyRows: 36 },
    view: {},
  },
} as const

test('the pane draws swimming sharks, on desktop and terminal', async ($, on) => {
  on('command.register', () => ({ value: { command: 'sharks' } }))
  on('ui.open', () => ({ value: { isPlaced: true } }))
  on('session.start', (_, e) => ({ cwd: e.cwd }))

  await $.session.start({ cwd: '/', surface: 'desktop', isInteractive: true })

  for (const surface of ['desktop', 'terminal'] as const) {
    const ui = await $.ui.mount({ ...PANE, surface })
    await ui.resize({ columns: 70, rows: 36, in: 'sharks' })
    await ui.advance(2000)

    const rows = await ui.findAll({ type: 'Text', in: 'sharks' })
    // One Text per row plus a Text per colour run in it.
    expect(rows.length).toBeGreaterThan(36)
    const everything = rows.map(r => r.text ?? '').join('')
    expect(everything).toMatch(/-/) // fish
    expect(everything).toMatch(/[%SX8@#]/) // shark skin

    // The picture moves between frames.
    const before = everything
    await ui.advance(1000)
    const after = (await ui.findAll({ type: 'Text', in: 'sharks' }))
      .map(r => r.text ?? '')
      .join('')
    expect(after).not.toBe(before)
    await ui.unmount()
  }
})
