import type { Register } from 'claude-code'

const PANE = 'ascii-sharks'

// Kinds: classic, hammerhead, zebra, tiger, greathammer, mako, thresher, nurse.
// The first is the biggest; sizes are relative to it.
const SHARKS = [
  { kind: 'hammerhead', size: 1 },
  { kind: 'thresher', size: 0.9 },
  { kind: 'mako', size: 0.8 },
]

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    await $.command.register({
      name: 'sharks',
      description: 'Open the ASCII sharks pane',
    })
    void $.ui.open({ id: PANE, title: 'Sharks' })

    return next(e)
  })

  on('command.run', { command: 'sharks' }, async $ => {
    const opened = await $.ui.open({ id: PANE, title: 'Sharks' })

    return {
      text: opened.isPlaced
        ? 'Sharks pane opened.'
        : `The pane is open but no screen is drawing it yet: ${opened.reason}`,
    }
  })

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const ui = $.ui.resolve(e)
    const { Text } = ui

    // Only the desktop app and the terminal can draw a Client region.
    if (!('Client' in ui)) {
      return <Text dimColor>The sharks need the desktop app or the terminal.</Text>
    }
    const { Client } = ui

    return (
      <Client
        key="sharks"
        module="./shark-view.js"
        props={{ sharks: SHARKS }}
        width={Math.max(20, e.props.bodyColumns)}
        height={Math.max(8, e.props.scroll.bodyRows)}
      />
    )
  })
}
